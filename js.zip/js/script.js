/* BitLegends — Original clicker with Boost Cards
   - Legally distinct terms & UI (no Hamster IP)
   - Tap Profit (TP) & Auto Profit (AP)
   - Boost Cards grid + scaling costs
   - Level-based avatar (your Imgur links)
   - Daily streak, milestones, prestige
   - Local save/load + local leaderboard
*/

(() => {
  // ---------- DOM ----------
  const $ = (q) => document.querySelector(q);
  const $$ = (q) => document.querySelectorAll(q);

  // Game elements
  const coinsEl = $('#coins'), levelEl = $('#level'), tpEl = $('#tp'), apEl = $('#ap');
  const clicksEl = $('#clicks'), toNextEl = $('#toNext'), progressEl = $('#progress'), hintEl = $('#hint');
  const character = $('#character'), avatar = $('#avatar'), tapRing = $('#tapRing');
  const tapBtn = $('#tapBtn'), dailyBtn = $('#dailyBtn');

  // Rewards / Prestige
  const streakEl = $('#streak'), prestigeEl = $('#prestige');
  const claimDailyBtn = $('#claimDaily'), checkMilestonesBtn = $('#checkMilestones'), prestigeBtn = $('#prestigeBtn');

  // Cards
  const cardsGrid = $('#cardsGrid');

  // Profile / Save
  const nameInp = $('#playerName'), exportBtn = $('#exportBtn'), importBtn = $('#importBtn'), importFile = $('#importFile'), wipeBtn = $('#wipeBtn');
  const pLevel = $('#pLevel'), pCoins = $('#pCoins'), pTP = $('#pTP'), pAP = $('#pAP');

  // Leaderboard
  const seedBoardBtn = $('#seedBoard'), saveScoreBtn = $('#saveScore'), boardBody = $('#boardBody');

  // Toast
  const toast = $('#toast');
  const showToast = (msg, ms=1400) => { toast.textContent = msg; toast.classList.add('show'); setTimeout(()=>toast.classList.remove('show'), ms); };

  // ---------- Audio (original beeps) ----------
  const AC = (window.AudioContext||window.webkitAudioContext) ? new (window.AudioContext||window.webkitAudioContext)() : null;
  function beep(freq=540, dur=.06, type='triangle', vol=.06){
    if(!AC) return;
    const o=AC.createOscillator(), g=AC.createGain();
    o.type=type; o.frequency.value=freq; g.gain.value=vol;
    o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime+dur);
  }
  const vibrate = (ms=12)=> navigator.vibrate && navigator.vibrate(ms);

  // ---------- Legal-safe: our own names/assets ----------
  function getImageByLevel(lv){
    if (lv >= 1 && lv <= 9)   return "https://i.imgur.com/4v3I3ln.png";
    if (lv >= 10 && lv <= 24) return "https://i.imgur.com/tByPxsC.png";
    if (lv >= 25 && lv <= 39) return "https://i.imgur.com/iawZVnm.png";
    if (lv >= 40 && lv <= 54) return "https://i.imgur.com/EYqiGoT.png";
    if (lv >= 55 && lv <= 69) return "https://i.imgur.com/hxcZKLf.png";
    if (lv >= 70 && lv <= 84) return "https://i.imgur.com/zlFSJGx.png";
    if (lv >= 85 && lv <= 99) return "https://i.imgur.com/g6KJoDt.png";
    if (lv >= 100)            return "https://i.imgur.com/0j4b78r.png";
    return "";
  }

  // ---------- Save ----------
  const SAVE_KEY = 'bl_v4_save';
  const BOARD_KEY = 'bl_v4_board';

  const S = {
    name: 'Player',
    coins: 0,
    level: 1,
    clicks: 0,
    tp: 1,       // Tap Profit
    ap: 0,       // Auto Profit
    lastDaily: 0,
    streak: 0,
    prestige: 0,
    milestones: {10:false,25:false,50:false,75:false,100:false},
    cards: {},   // { id: level }
  };

  function save(){ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(S)); }catch(e){} }
  function load(){ try{ const r=localStorage.getItem(SAVE_KEY); if(r) Object.assign(S, JSON.parse(r)); }catch(e){} }

  // ---------- Progression ----------
  const needForNext = (lv)=> Math.max(1000, lv*1000);

  function applyLevelVisual(){
    const src = getImageByLevel(S.level);
    character.src = src; avatar.src = src;
  }
  function recalcLevel(){
    const newLv = Math.min(100, Math.floor(S.coins/1000)+1);
    if(newLv !== S.level){
      S.level = newLv; applyLevelVisual();
      beep(900,.08,'sine',.06); showToast(`Level Up → ${S.level}`);
    }
  }
  function updateBars(){
    const need = needForNext(S.level);
    const cur = S.coins % need;
    const pct = Math.min(100, Math.floor(cur/need*100));
    progressEl.style.width = pct + '%';
    toNextEl.textContent = (need-cur).toLocaleString();
  }
  function updateUI(){
    coinsEl.textContent = S.coins.toLocaleString();
    levelEl.textContent = S.level;
    tpEl.textContent = S.tp.toLocaleString();
    apEl.textContent = S.ap.toLocaleString();
    clicksEl.textContent = S.clicks.toLocaleString();
    streakEl.textContent = S.streak;
    prestigeEl.textContent = S.prestige;
    pLevel.textContent = S.level; pCoins.textContent = S.coins.toLocaleString();
    pTP.textContent = S.tp.toLocaleString(); pAP.textContent = S.ap.toLocaleString();
    nameInp.value = S.name;
    updateBars();
  }

  // ---------- Tap ----------
  $('#tapBtn').addEventListener('click', (e)=>{
    S.coins += S.tp; S.clicks++;
    tapRing.style.opacity='0.9'; tapRing.style.transform='scale(1.05)';
    setTimeout(()=>{ tapRing.style.opacity='0'; tapRing.style.transform='scale(.92)'; }, 260);
    floatNumber(e.clientX, e.clientY, `+${S.tp}`);
    beep(520,.04,'square',.05); vibrate(12);
    recalcLevel(); save(); updateUI();
  });

  function floatNumber(x,y,text){
    const el = document.createElement('div'); el.textContent=text;
    el.style.position='fixed'; el.style.left=x+'px'; el.style.top=y+'px';
    el.style.color='#ffd166'; el.style.fontWeight='900'; el.style.transition='transform .6s, opacity .6s'; el.style.zIndex='9999';
    document.body.appendChild(el);
    requestAnimationFrame(()=>{ el.style.transform='translateY(-40px)'; el.style.opacity='0'; });
    setTimeout(()=> el.remove(), 650);
  }

  // ---------- Auto Profit ----------
  setInterval(()=>{ if(S.ap>0){ S.coins += S.ap; recalcLevel(); save(); updateUI(); }}, 1000);

  // ---------- Daily Reward ----------
  function canClaimDaily(){
    const DAY = 24*3600*1000, n=Date.now();
    return (!S.lastDaily) || (n - S.lastDaily) >= DAY;
  }
  function claimDailyBase(){
    const n=Date.now(), DAY=24*3600*1000;
    if (S.lastDaily && (n - S.lastDaily) < DAY){ showToast('Already claimed today'); beep(180,.05,'sawtooth',.04); return; }
    if (S.lastDaily && (n - S.lastDaily) < 2*DAY) S.streak = (S.streak||0)+1; else S.streak = 1;
    S.lastDaily = n;
    const reward = 4000 + S.level*300 + S.streak*250 + S.prestige*500;
    S.coins += reward;
    showToast(`Daily +${reward.toLocaleString()} (Streak ${S.streak})`);
    beep(1100,.08,'triangle',.06); vibrate([10,30,10]);
    recalcLevel(); save(); updateUI();
  }
  dailyBtn.addEventListener('click', claimDailyBase);
  claimDailyBtn.addEventListener('click', claimDailyBase);

  // ---------- Milestones ----------
  function checkMilestones(){
    const grants = [];
    const award = (lv, amount)=>{
      if (!S.milestones[lv] && S.level>=lv){ S.milestones[lv]=true; S.coins+=amount; grants.push({lv,amount}); }
    };
    award(10,  5000);
    award(25, 20000);
    award(50, 60000);
    award(75, 150000);
    award(100, 500000);
    if(grants.length){ beep(980,.1,'sine',.06); vibrate(20); showToast(`Milestones: +${grants.map(g=>g.amount.toLocaleString()).join(' + ')}`); recalcLevel(); save(); updateUI(); }
    else showToast('No new milestones');
  }
  checkMilestonesBtn.addEventListener('click', checkMilestones);

  // ---------- Prestige ----------
  prestigeBtn.addEventListener('click', ()=>{
    if (S.level < 20){ showToast('Reach level 20 to prestige'); return; }
    if (!confirm('Prestige will reset progress and grant permanent +1 TP per prestige. Continue?')) return;
    S.prestige += 1;
    S.tp += 1; // permanent bonus each time
    // reset dynamic progress
    S.coins=0; S.level=1; S.clicks=0; S.ap=0; S.cards={}; S.milestones={10:false,25:false,50:false,75:false,100:false};
    save(); updateUI(); renderCards(); showToast('Prestiged! Permanent TP bonus applied');
  });

  // ---------- Cards (original Boost Cards) ----------
  const CARD_DEFS = [
    { id:'tap-chip',     icon:'🖱️', title:'Tap Chip',       desc:'+1 TP each level',      type:'tp',  base:200,   grow:1.28, add:()=> S.tp += 1 },
    { id:'gold-finger',  icon:'☝️', title:'Gold Finger',    desc:'×2 TP (multiplicative)',type:'mul', base:4_000, grow:1.8,  add:()=> S.tp = Math.max(1, Math.floor(S.tp*2)) },
    { id:'nano-rig',     icon:'🛠️', title:'Nano Rig',       desc:'+1 AP each level',      type:'ap',  base:800,   grow:1.33, add:()=> S.ap += 1 },
    { id:'quantum-node', icon:'🛰️', title:'Quantum Node',   desc:'+5 AP each level',      type:'ap',  base:12_000,grow:1.5,  add:()=> S.ap += 5 },
    { id:'hash-optimizer',icon:'⚙️', title:'Hash Optimizer', desc:'TP +5 each level',      type:'tp',  base:6_000, grow:1.45, add:()=> S.tp += 5 },
    { id:'credit-vault', icon:'💳', title:'Credit Vault',    desc:'Instant +5,000 coins',  type:'burst',base:9_000, grow:1.55, add:()=> S.coins += 5_000 },
  ];

  function cardLevel(id){ return S.cards[id] || 0; }
  function cardCost(def){ const lv = cardLevel(def.id); return Math.floor(def.base * Math.pow(def.grow, lv)); }

  function renderCards(){
    cardsGrid.innerHTML = '';
    CARD_DEFS.forEach(def=>{
      const lv = cardLevel(def.id);
      const cost = cardCost(def);
      const el = document.createElement('div'); el.className='card';
      el.innerHTML = `
        <div class="row">
          <div class="badge">${def.icon}</div>
          <div class="title">${def.title}</div>
          <div class="badge">Lv ${lv}</div>
        </div>
        <div class="desc">${def.desc}</div>
        <div class="row">
          <div class="price">Cost: <b>${cost.toLocaleString()}</b></div>
          <button class="tiny" data-buy="${def.id}">Upgrade</button>
        </div>
      `;
      cardsGrid.appendChild(el);
    });

    // bind
    cardsGrid.querySelectorAll('button[data-buy]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.getAttribute('data-buy');
        const def = CARD_DEFS.find(d=>d.id===id);
        const cost = cardCost(def);
        if (S.coins < cost){ showToast('Not enough BitCreds'); beep(180,.05,'sawtooth',.04); return; }
        S.coins -= cost;
        S.cards[id] = (S.cards[id]||0) + 1;
        def.add();
        beep(720,.06,'square',.05); vibrate(18);
        recalcLevel(); save(); updateUI(); renderCards();
        showToast(`${def.title} upgraded (Lv ${S.cards[id]})`);
      });
    });
  }

  // ---------- Tabs ----------
  $$('.tab-btn').forEach(b=>{
    b.addEventListener('click', ()=>{
      $$('.tab-btn').forEach(t=>t.classList.remove('active'));
      $$('.tab').forEach(t=>t.classList.remove('active'));
      b.classList.add('active');
      $('#tab-' + b.dataset.tab).classList.add('active');
      if (b.dataset.tab==='cards') renderCards();
    });
  });

  // ---------- Profile / Save I/O ----------
  nameInp.addEventListener('change', ()=>{ S.name = nameInp.value || 'Player'; save(); updateUI(); });
  exportBtn.addEventListener('click', ()=>{
    const blob = new Blob([JSON.stringify(S)], {type:'application/json'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href=url; a.download='bitlegends-save.json'; a.click(); URL.revokeObjectURL(url);
  });
  importBtn.addEventListener('click', ()=> importFile.click());
  importFile.addEventListener('change', (e)=>{
    const f=e.target.files[0]; if(!f) return;
    const r = new FileReader();
    r.onload = ev=>{
      try{
        const data = JSON.parse(ev.target.result);
        Object.assign(S, data);
        save(); applyLevelVisual(); updateUI(); renderCards();
        showToast('Save imported');
      }catch(err){ alert('Invalid file'); }
    };
    r.readAsText(f);
  });
  wipeBtn.addEventListener('click', ()=>{
    if (!confirm('Wipe local save?')) return;
    localStorage.removeItem(SAVE_KEY); location.reload();
  });

  // ---------- Leaderboard (local only) ----------
  function getBoard(){ try{ return JSON.parse(localStorage.getItem(BOARD_KEY)||'[]'); }catch(e){ return []; } }
  function setBoard(v){ localStorage.setItem(BOARD_KEY, JSON.stringify(v)); }
  function renderBoard(){
    const rows = getBoard().sort((a,b)=> b.coins - a.coins).slice(0,50);
    boardBody.innerHTML = rows.map((r,i)=> `<tr><td>${i+1}</td><td>${r.name}</td><td>${r.coins.toLocaleString()}</td><td>${r.level}</td></tr>`).join('');
  }
  seedBoardBtn.addEventListener('click', ()=>{
    const demo = Array.from({length:10},(_,i)=>({name:'P'+(i+1), coins:Math.floor(Math.random()*150000), level:Math.floor(Math.random()*100)+1}));
    setBoard(demo); renderBoard(); showToast('Board seeded');
  });
  saveScoreBtn.addEventListener('click', ()=>{
    const b = getBoard(); b.push({name:S.name, coins:S.coins, level:S.level}); setBoard(b); renderBoard(); showToast('Score saved');
  });

  // ---------- Init ----------
  load();
  applyLevelVisual();
  updateUI();
  renderBoard();
  renderCards();
  hintEl.textContent = canClaimDaily() ? 'Daily is ready!' : 'Grind to unlock more cards';

})();